#!/bin/bash

BUNDLE_ID="app.ariidjsdev.VLyrics"
APP_NAME="VLyrics"

# Ensure we have sudo early for the daemon/pkgutil steps
echo "🔐 Please enter your password to reset system services..."
sudo -v

echo "🧹 Starting deep-clean for $APP_NAME ($BUNDLE_ID)..."

# 1. Kill App and Background Daemons
echo "[1/6] Killing app and TCC daemons..."
pkill -f "$BUNDLE_ID" 2>/dev/null
pkill -f "$APP_NAME" 2>/dev/null
sudo killall tccd  # Forces the privacy daemon to refresh its cache

# 2. Reset Privacy Permissions
echo "[2/6] Nuking privacy permissions from TCC database..."
tccutil reset All "$BUNDLE_ID"
# Specific resets for file/folder access just in case
tccutil reset SystemPolicyAllFiles "$BUNDLE_ID" 2>/dev/null
tccutil reset SystemPolicyDownloadsFolder "$BUNDLE_ID" 2>/dev/null

# 3. Delete Library, Cache, and Sandbox Containers
echo "[3/6] Removing all local data and Sandbox containers..."
rm -rf ~/Library/Application\ Support/"$APP_NAME"
rm -rf ~/Library/Caches/"$BUNDLE_ID"
rm -rf ~/Library/Preferences/"$BUNDLE_ID".plist
rm -rf ~/Library/Saved\ Application\ State/"$BUNDLE_ID".savedState
rm -rf ~/Library/HTTPStorages/"$BUNDLE_ID"
# Sandboxed apps store their permissions and data here:
rm -rf ~/Library/Containers/"$BUNDLE_ID"

# 4. Remove Binary
if [ -d "/Applications/$APP_NAME.app" ]; then
    echo "[4/6] Removing app from /Applications..."
    sudo rm -rf "/Applications/$APP_NAME.app"
fi

# 5. Rebuild Launch Services Database
# This makes macOS "forget" it ever saw this app version
echo "[5/6] Rebuilding Launch Services database (this may take a second)..."
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -kill -r -domain local -domain system -domain user

# 6. Clear Install Receipts and Defaults
echo "[6/6] Finalizing cleanup..."
sudo pkgutil --forget "$BUNDLE_ID" 2>/dev/null
killall cfprefsd

echo "✅ Done! Important: Change your Build Number in Xcode before running again to guarantee the popup shows."
